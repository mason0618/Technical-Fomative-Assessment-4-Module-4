# Tasks for Today Management System

This CodeIgniter 4 project implements the IT0049 TSA1, TFA3, and TFA4 activities.

## Pages

- `/` shows only tasks scheduled for today.
- `/tasks` shows all tasks ordered by date.
- `/profile` shows the demo user.
- `/about` identifies the developer.

## Setup

1. Make sure PHP, MySQL, Composer, and the PHP `intl`, `fileinfo`, and `gd` extensions are installed.
2. Copy `.env.example` to `.env` and set the database connection.
3. Import `database.sql` into MySQL.
4. Run `php spark serve` and open the local URL.

The database script creates the `tasks` table, the `users` table, eight task records across several dates, and one demo user.

## Forms and uploads

- `/customers/new` and `/customers/edit/{id}` create and edit customer accounts.
- `/users/new` and `/users/edit/{id}` create and edit user accounts.
- Customer and user forms validate required fields and keep entered values when validation fails.
- User edit accepts JPG or PNG avatar files up to 2MB, prepares a 160 by 160 image, and saves the filename in the database.
- User listings show the saved avatar or a placeholder when no avatar is available.

## Sessions and authentication

- `/login` checks the username and password using a hashed password.
- Customer and user account pages require an active session.
- `/logout` destroys the session and returns to the login page.
- Demo login: username `mason`, password `password`.

## What is CodeIgniter?

CodeIgniter is a PHP full-stack web framework that is light, fast, flexible and secure.
More information can be found at the [official site](https://codeigniter.com).

This repository holds a composer-installable app starter.
It has been built from the
[development repository](https://github.com/codeigniter4/CodeIgniter4).

More information about the plans for version 4 can be found in [CodeIgniter 4](https://forum.codeigniter.com/forumdisplay.php?fid=28) on the forums.

You can read the [user guide](https://codeigniter.com/user_guide/)
corresponding to the latest version of the framework.

## Installation & updates

`composer create-project codeigniter4/appstarter` then `composer update` whenever
there is a new release of the framework.

When updating, check the release notes to see if there are any changes you might need to apply
to your `app` folder. The affected files can be copied or merged from
`vendor/codeigniter4/framework/app`.

## Setup

Copy `env` to `.env` and tailor for your app, specifically the baseURL
and any database settings.

## Important Change with index.php

`index.php` is no longer in the root of the project! It has been moved inside the *public* folder,
for better security and separation of components.

This means that you should configure your web server to "point" to your project's *public* folder, and
not to the project root. A better practice would be to configure a virtual host to point there. A poor practice would be to point your web server to the project root and expect to enter *public/...*, as the rest of your logic and the
framework are exposed.

**Please** read the user guide for a better explanation of how CI4 works!

## Repository Management

We use GitHub issues, in our main repository, to track **BUGS** and to track approved **DEVELOPMENT** work packages.
We use our [forum](http://forum.codeigniter.com) to provide SUPPORT and to discuss
FEATURE REQUESTS.

This repository is a "distribution" one, built by our release preparation script.
Problems with it can be raised on our forum, or as issues in the main repository.

## Server Requirements

PHP version 8.2 or higher is required, with the following extensions installed:

- [intl](http://php.net/manual/en/intl.requirements.php)
- [mbstring](http://php.net/manual/en/mbstring.installation.php)

> [!WARNING]
> - The end of life date for PHP 7.4 was November 28, 2022.
> - The end of life date for PHP 8.0 was November 26, 2023.
> - The end of life date for PHP 8.1 was December 31, 2025.
> - If you are still using below PHP 8.2, you should upgrade immediately.
> - The end of life date for PHP 8.2 will be December 31, 2026.

Additionally, make sure that the following extensions are enabled in your PHP:

- json (enabled by default - don't turn it off)
- [mysqlnd](http://php.net/manual/en/mysqlnd.install.php) if you plan to use MySQL
- [libcurl](http://php.net/manual/en/curl.requirements.php) if you plan to use the HTTP\CURLRequest library
