<?php

namespace App\Controllers;

use App\Models\CustomerModel;

class Customers extends BaseController
{
    public function index()
    {
        $model = new CustomerModel();

        return view('customers', [
            'customers' => $model->orderBy('full_name', 'ASC')->findAll(),
        ]);
    }

    public function new()
    {
        $errors = [];

        if (strtolower($this->request->getMethod()) === 'post') {
            $rules = [
                'full_name' => 'required|max_length[100]',
                'email' => 'required|valid_email|max_length[100]',
                'phone' => 'permit_empty|max_length[20]',
            ];

            if ($this->validate($rules)) {
                (new CustomerModel())->insert([
                    'full_name' => $this->request->getPost('full_name'),
                    'email' => $this->request->getPost('email'),
                    'phone' => $this->request->getPost('phone'),
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                return redirect()->to('/customers');
            }

            $errors = service('validation')->getErrors();
        }

        return view('customer_form', ['customer' => null, 'formTitle' => 'New Customer', 'errors' => $errors]);
    }

    public function edit(int $id)
    {
        $model = new CustomerModel();
        $customer = $model->find($id);
        $errors = [];

        if ($customer === null) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if (strtolower($this->request->getMethod()) === 'post') {
            $rules = [
                'full_name' => 'required|max_length[100]',
                'email' => 'required|valid_email|max_length[100]',
                'phone' => 'permit_empty|max_length[20]',
            ];

            if ($this->validate($rules)) {
                $model->update($id, [
                    'full_name' => $this->request->getPost('full_name'),
                    'email' => $this->request->getPost('email'),
                    'phone' => $this->request->getPost('phone'),
                ]);
                return redirect()->to('/customers');
            }

            $errors = service('validation')->getErrors();
        }

        return view('customer_form', ['customer' => $customer, 'formTitle' => 'Edit Customer', 'errors' => $errors]);
    }
}
