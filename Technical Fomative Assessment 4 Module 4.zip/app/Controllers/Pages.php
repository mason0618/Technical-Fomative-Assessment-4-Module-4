<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Pages extends BaseController
{
    public function home()
    {
        $taskModel = new TaskModel();

        $data['tasks'] = $taskModel
            ->where('task_date', date('Y-m-d'))
            ->orderBy('created_at', 'ASC')
            ->findAll();

        $data['todayTotal'] = count($data['tasks']);
        $data['completedTotal'] = count(array_filter($data['tasks'], static fn ($task) => $task['status'] === 'completed'));
        $data['pendingTotal'] = $data['todayTotal'] - $data['completedTotal'];

        return view('home', $data);
    }

    public function about()
    {
        return view('about');
    }
}
