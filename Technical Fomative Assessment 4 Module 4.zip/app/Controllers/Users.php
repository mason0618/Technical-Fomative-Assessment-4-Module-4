<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index()
    {
        $model = new UserModel();

        return view('users', [
            'users' => $model->orderBy('full_name', 'ASC')->findAll(),
        ]);
    }

    public function new()
    {
        $errors = [];

        if (strtolower($this->request->getMethod()) === 'post') {
            $rules = [
                'username' => 'required|max_length[50]|is_unique[users.username]',
                'full_name' => 'required|max_length[100]',
                'email' => 'required|valid_email|max_length[100]',
            ];

            if ($this->validate($rules)) {
                (new UserModel())->insert([
                    'username' => $this->request->getPost('username'),
                    'full_name' => $this->request->getPost('full_name'),
                    'email' => $this->request->getPost('email'),
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                return redirect()->to('/users');
            }

            $errors = service('validation')->getErrors();
        }

        return view('user_form', ['user' => null, 'formTitle' => 'New User', 'errors' => $errors]);
    }

    public function edit(int $id)
    {
        $model = new UserModel();
        $user = $model->find($id);
        $errors = [];

        if ($user === null) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if (strtolower($this->request->getMethod()) === 'post') {
            $rules = [
                'username' => "required|max_length[50]|is_unique[users.username,id,{$id}]",
                'full_name' => 'required|max_length[100]',
                'email' => 'required|valid_email|max_length[100]',
                'avatar' => 'permit_empty|is_image[avatar]|mime_in[avatar,image/jpg,image/jpeg,image/png]|max_size[avatar,2048]',
            ];

            if ($this->validate($rules)) {
                $data = [
                    'username' => $this->request->getPost('username'),
                    'full_name' => $this->request->getPost('full_name'),
                    'email' => $this->request->getPost('email'),
                ];

                $file = $this->request->getFile('avatar');
                if ($file && $file->isValid() && ! $file->hasMoved()) {
                    $filename = bin2hex(random_bytes(8)) . '.' . $file->getExtension();
                    $uploadPath = FCPATH . 'uploads';
                    if (! is_dir($uploadPath)) {
                        mkdir($uploadPath, 0775, true);
                    }
                    service('image')->withFile($file->getTempName())->fit(160, 160)->save($uploadPath . DIRECTORY_SEPARATOR . $filename);
                    $data['avatar'] = $filename;
                }

                $model->update($id, $data);
                return redirect()->to('/users');
            }

            $errors = service('validation')->getErrors();
        }

        return view('user_form', ['user' => $user, 'formTitle' => 'Edit User', 'errors' => $errors]);
    }
}
