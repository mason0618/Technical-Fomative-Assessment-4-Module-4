<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a>
        <nav class="main-nav">
            <a href="<?= base_url('/') ?>">Home</a>
            <a href="<?= base_url('tasks') ?>">Task List</a>
            <a href="<?= base_url('customers') ?>">Customers</a>
            <a href="<?= base_url('users') ?>">Users</a>
            <a href="<?= base_url('profile') ?>">Profile</a>
            <a class="active" href="<?= base_url('about') ?>">About</a>
        </nav>
    </div>
</header>

<main class="page-container">
    <div class="page-heading">
        <h1>About</h1>
        <p>Information about this project.</p>
    </div>
    <section class="about-card">
        <p>This is a simple Tasks for Today Management System developed using CodeIgniter 4.</p>
        <p><strong>Developer:</strong> Mason Andrei Cedo</p>
    </section>
</main>

<footer class="site-footer">Tasks for Today Management System</footer>
</body>
</html>
