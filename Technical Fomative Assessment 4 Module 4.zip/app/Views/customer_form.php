<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($formTitle) ?> | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header"><div class="header-content"><a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a><nav class="main-nav"><a href="<?= base_url('customers') ?>">Customers</a><a href="<?= base_url('users') ?>">Users</a><a href="<?= base_url('profile') ?>">Profile</a><a href="<?= base_url('logout') ?>">Logout</a></nav></div></header>
<main class="page-container form-page">
    <div class="page-heading"><h1><?= esc($formTitle) ?></h1><p>Enter the customer details below.</p></div>
    <form class="form-card" method="post">
        <?= csrf_field() ?>
        <?php if ($errors): ?><div class="form-errors"><ul><?php foreach ($errors as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <label for="full_name">Full name</label>
        <input id="full_name" name="full_name" type="text" value="<?= esc(old('full_name', $customer['full_name'] ?? '')) ?>">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" value="<?= esc(old('email', $customer['email'] ?? '')) ?>">
        <label for="phone">Phone</label>
        <input id="phone" name="phone" type="text" value="<?= esc(old('phone', $customer['phone'] ?? '')) ?>">
        <div class="form-actions"><a class="button secondary" href="<?= base_url('customers') ?>">Cancel</a><button class="button" type="submit">Save Customer</button></div>
    </form>
</main>
</body>
</html>
