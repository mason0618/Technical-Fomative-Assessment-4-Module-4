<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a>
        <nav class="main-nav">
            <a class="active" href="<?= base_url('/') ?>">Home</a>
            <a href="<?= base_url('tasks') ?>">Task List</a>
            <a href="<?= base_url('customers') ?>">Customers</a>
            <a href="<?= base_url('users') ?>">Users</a>
            <a href="<?= base_url('profile') ?>">Profile</a>
            <a href="<?= base_url('about') ?>">About</a>
        </nav>
    </div>
</header>

<main class="page-container">
    <section class="welcome-card">
        <div class="welcome-top">
            <div>
                <p class="eyebrow">DAILY OVERVIEW</p>
                <h1>Tasks for Today</h1>
                <p>Here are the tasks scheduled for <?= date('F j, Y') ?>.</p>
            </div>
            <div class="today-badge">Today</div>
        </div>
        <div class="summary-cards">
            <div class="summary-card blue">
                <span class="summary-label">Total tasks</span>
                <strong><?= esc($todayTotal) ?></strong>
            </div>
            <div class="summary-card green">
                <span class="summary-label">Completed</span>
                <strong><?= esc($completedTotal) ?></strong>
            </div>
            <div class="summary-card yellow">
                <span class="summary-label">Pending</span>
                <strong><?= esc($pendingTotal) ?></strong>
            </div>
        </div>
        <?php if ($tasks === []): ?>
            <p class="empty-message">There are no tasks for today.</p>
        <?php else: ?>
            <div class="task-list">
                <?php foreach ($tasks as $task): ?>
                    <div class="task-item">
                        <div>
                            <strong><?= esc($task['title']) ?></strong>
                            <small><?= esc($task['task_date']) ?></small>
                        </div>
                        <span class="status <?= esc($task['status']) ?>"><?= esc(ucfirst($task['status'])) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>

<footer class="site-footer">Tasks for Today Management System</footer>
</body>
</html>
