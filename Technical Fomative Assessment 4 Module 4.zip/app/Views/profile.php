<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a>
        <nav class="main-nav">
            <a href="<?= base_url('/') ?>">Today</a>
            <a href="<?= base_url('tasks') ?>">Task List</a>
            <a href="<?= base_url('customers') ?>">Customers</a>
            <a href="<?= base_url('users') ?>">Users</a>
            <a class="active" href="<?= base_url('profile') ?>">Profile</a>
            <a href="<?= base_url('about') ?>">About</a>
        </nav>
    </div>
</header>
<main class="page-container">
    <div class="page-heading">
        <h1>Profile</h1>
        <p>Demo user information.</p>
    </div>
    <section class="about-card">
        <div class="profile-heading">
            <div class="profile-avatar">M</div>
            <div>
                <h2><?= esc($user['full_name']) ?></h2>
                <p class="profile-role">System user</p>
            </div>
        </div>
        <div class="profile-details">
            <p><span>Username</span><?= esc($user['username']) ?></p>
            <p><span>Email address</span><?= esc($user['email']) ?></p>
        </div>
    </section>
</main>
<footer class="site-footer">Tasks for Today Management System</footer>
</body>
</html>
