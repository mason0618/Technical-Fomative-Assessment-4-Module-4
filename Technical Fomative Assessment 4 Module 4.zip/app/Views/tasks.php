<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task List | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header">
    <div class="header-content">
        <a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a>
        <nav class="main-nav">
            <a href="<?= base_url('/') ?>">Today</a>
            <a class="active" href="<?= base_url('tasks') ?>">Task List</a>
            <a href="<?= base_url('customers') ?>">Customers</a>
            <a href="<?= base_url('users') ?>">Users</a>
            <a href="<?= base_url('profile') ?>">Profile</a>
            <a href="<?= base_url('about') ?>">About</a>
        </nav>
    </div>
</header>
<main class="page-container">
    <div class="page-heading">
        <h1>Task List</h1>
        <p>All tasks in the system, ordered by date.</p>
    </div>
    <section class="table-card">
        <table>
            <thead><tr><th>Task</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                <tr>
                    <td><?= esc($task['title']) ?></td>
                    <td><span class="status <?= esc($task['status']) ?>"><?= esc(ucfirst($task['status'])) ?></span></td>
                    <td><?= esc($task['task_date']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>
<footer class="site-footer">Tasks for Today Management System</footer>
</body>
</html>
