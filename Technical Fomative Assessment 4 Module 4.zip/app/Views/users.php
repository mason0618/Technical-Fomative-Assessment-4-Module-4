<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
<header class="site-header"><div class="header-content"><a class="brand" href="<?= base_url('/') ?>">Tasks <span>Today</span></a><nav class="main-nav"><a href="<?= base_url('/') ?>">Today</a><a href="<?= base_url('tasks') ?>">Task List</a><a href="<?= base_url('customers') ?>">Customers</a><a href="<?= base_url('users') ?>" class="active">Users</a><a href="<?= base_url('profile') ?>">Profile</a><a href="<?= base_url('about') ?>">About</a><a href="<?= base_url('logout') ?>">Logout</a></nav></div></header>
<main class="page-container">
    <div class="page-heading page-heading-row"><div><h1>User Accounts</h1><p>Manage users and profile pictures.</p></div><a class="button" href="<?= base_url('users/new') ?>">+ New User</a></div>
    <section class="table-card">
        <table>
            <thead><tr><th>Avatar</th><th>Username</th><th>Full Name</th><th>Email</th><th>Action</th></tr></thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><img class="avatar-small" src="<?= base_url('uploads/' . ($user['avatar'] ?: 'placeholder.svg')) ?>" alt="User avatar"></td>
                    <td><?= esc($user['username']) ?></td>
                    <td><?= esc($user['full_name']) ?></td>
                    <td><?= esc($user['email']) ?></td>
                    <td><a class="table-link" href="<?= base_url('users/edit/' . $user['id']) ?>">Edit</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>
<footer class="site-footer">Tasks for Today Management System</footer>
</body>
</html>
